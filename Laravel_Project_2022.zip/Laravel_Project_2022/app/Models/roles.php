<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class roles extends Model
{


    protected $fillable = [
        'role',
        'RoleId',

    ];





    public function getuser(){
        return $this->hasMany(User::class );
    }




    use HasFactory;
}
