<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\menu;

class restaurant extends Model
{
    use HasFactory;

    protected $fillable =[
        'id',
        'name',
        'password',
        'image',
        'email',
        'number',
        'address'
    ];


    public function getMenu(){
        return $this->hasOne(menu::class);
    }


}
