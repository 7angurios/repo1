<?php

namespace App\Http\Controllers;

use App\Models\orderitem;
use App\Models\restaurant;
use Illuminate\Http\Request;
use App\Models\cart;
use App\Models\menu;
use App\Models\cartitem;
use Illuminate\Support\Facades\DB;
use function Termwind\renderUsing;
use App\Models\order;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\CartitemController;
use App\Http\Controllers\MenuController;
use App\Http\Controllers\CartController;
use Illuminate\Support\Facades\Auth;

class OrderitemController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {


    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\orderitem  $orderitem
     * @return \Illuminate\Http\Response
     */
    public function show(orderitem $orderitem)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\orderitem  $orderitem
     * @return \Illuminate\Http\Response
     */
    public function edit(orderitem $orderitem)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\orderitem  $orderitem
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, orderitem $orderitem)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\orderitem  $orderitem
     * @return \Illuminate\Http\Response
     */
    public function destroy(orderitem $orderitem)
    {
        //
    }

    public function orderitems (Request $request)
    {
        $totalPrice = 0;

        $cartitems = DB::table('cartitems')
            ->join('menus', 'menus.id', '=', 'cartitems.menu_id')
            ->where('cartitems.cart_id' , '=' , Auth::user()->id)
            ->select('menus.restaurant_id')
            ->distinct()
            ->get();

        $cartitemss =cartitem::where('cart_id','=',Auth::user()->id)->get();

        foreach($cartitemss as $obj)
        {
            $datamenu=menu::where('id','=',$obj->menu_id)->first();
            $totalPrice=$totalPrice+($datamenu->price * $obj->quantity);
        }

        foreach ($cartitems as $temp)
        {
            $order=new order();

            $order->user_id=Auth::id();
            $order->restaurant_id=$temp->restaurant_id;
            $order->status='pending';
            $order->totalPrice =$totalPrice;
            $order->address='beirut';
            $order->save();
        }


        //$cart=cart::where('user_id','=',Auth::id())->first();
        $cartitem=cartitem::where('cart_id','=',Auth::id())->get();

        foreach($cartitem as $temp2)
        {
            $resto = DB::table('restaurants')
                ->join('menus', 'restaurants.id', '=', 'menus.restaurant_id')
                ->join('cartitems', 'menus.id', '=', 'cartitems.menu_id')
                ->where('cartitems.menu_id','=',$temp2->menu_id)
                ->select('restaurants.*')
                ->first();


            $orders=order::where('restaurant_id','=',$resto->id)->latest('created_at')->first();
            $orderitems=new orderitem();
            $orderitems->menu_id=$temp2->menu_id;
            $orderitems->orders_id=$orders->id;
            $orderitems->quantity=$temp2->quantity;
            $orderitems->save();
            $del=cartitem::where('cart_id','=',Auth::user()->id)->where('menu_id','=',$temp2->menu_id);
            $del->delete();
        }
                return redirect()->back();
    }

    public function showOrderHistory ()
    {
//        select users.fname , users.lname , restaurants.name , orders.address ,orders.totalprice from orders
//        JOIN users on orders.user_id = users.id
//        JOIN restaurants on restaurants.id = orders.restaurant_id;
        $showOrders = DB::table('orders')
            ->join('users' , 'users.id' , '=' , 'orders.user_id')
            ->join('restaurants' , 'restaurants.id', '=' , 'orders.restaurant_id')
            ->select('users.fname' , 'users.lname' , 'restaurants.name' , 'orders.address' ,'orders.status', 'orders.totalprice')
            ->where('orders.user_id' , '=' , Auth::user()->id)
            ->get();

        return view('orderhistory')
            ->with('showOrders' , $showOrders);
    }




}
