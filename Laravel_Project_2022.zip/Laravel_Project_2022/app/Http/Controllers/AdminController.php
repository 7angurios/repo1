<?php

namespace App\Http\Controllers;

use App\Models\admin;
use App\Models\restaurant;
use App\Models\User;
use App\Models\cart;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

    }

    /**
     * Display the specified resource.
     *
     * @param \App\Models\admin $admin
     * @return \Illuminate\Http\Response
     */
    public function show(admin $admin)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param \App\Models\admin $admin
     * @return \Illuminate\Http\Response
     */
    public function edit(admin $admin)
    {

    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param \App\Models\admin $admin
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, admin $restaurant)
    {

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param \App\Models\admin $admin
     * @return \Illuminate\Http\Response
     */
    public function destroy(restaurant $restaurant)
    {

    }

    public function adminlog(Request $request)
    {

    }


    public function uprestau(restaurant $restaurant)
    {

        $data = restaurant::find($restaurant->id);


        return view ("editrestau")
            ->with("mydata",$data);
    }

    public function upclient(user $user)
    {
        $data = user::find($user->id);
        return view ("editclient")
            ->with("mydata",$data);

    }



    public function subupdate(request $request,restaurant $restaurant)
    {

        $data = restaurant::find($restaurant->id);
        $data->name = $request->input("name");
        $data->image = $request->input("image");
        $data->email = $request->input("email");
        $data->number = $request->input("number");
        $data->address = $request->input("address");
        $data->save();

        $rest = restaurant::all();
        return view ("adminlistrest")
            ->with("mydata", $rest);
    }

    public function subupdateClient(request $request,user $user)
    {

        $data = user::find($user->id);
        $data->fname = $request->input("fname");
        $data->lname = $request->input("lname");
        $data->contact = $request->input("contact");
        $data->address = $request->input("address");
        $data->email = $request->input("email");

        $data->save();

        $client=user::where('Role_id',1)->get();
        $cook=user::where('Role_id',2)->get();
        return view ("adminlistclient")

            ->with("mydata" , $client)
            ->with("mydata2",$cook);

    }

    public function deleteclient(user $user)
    {
        if($user->Role_id==1) {

            $data = cart::where('user_id', $user->id);
            $data->delete();
            $user->delete();
        }

        elseif($user->Role_id==2) {
            $user->delete();
        }


        $client=user::where('Role_id',1)->get();
        $cook=user::where('Role_id',2)->get();



        return view ("adminlistclient")
            ->with("mydata" , $client)
            ->with("mydata2",$cook);
    }

    public function listrest(){
        $data = restaurant::all();
        return view('adminlistrest')->with("mydata",$data);
    }

    public function listclient(){
        $client = User::where("Role_id",1)->get();
        $cook = User::where("Role_id",2)->get();

        return view('adminlistclient')->with("mydata",$client)->with("mydata2",$cook);
    }

    public function adminpage(){
        return view('adminpage');
    }


    public function request(){

        $data = restaurant::where("status",1)->get();
        return view('adminrequest')->with("mydata",$data);
    }
    public function accept(restaurant $restaurant){
        $restaurant->status=0;
        $restaurant->save();

        $data = restaurant::where("status",1)->get();
        return view('adminrequest')->with("mydata",$data);
    }

    public function request2(){

        $data = restaurant::where("status",0)->get();
        return view('adminreject')->with("mydata",$data);
    }

    public function reject(restaurant $restaurant){
        $restaurant->status=1;
        $restaurant->save();

        $data = restaurant::where("status",0)->get();
        return view('adminreject')->with("mydata",$data);
    }


}
