<?php

namespace App\Http\Controllers;
use App\Models\cart;
use App\Models\cartitem;
use App\Models\menu;
use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Controllers\MenuController;
use Illuminate\Support\Facades\Auth;

class CartitemController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
//        $data = cartitem::where('cart_id',Auth::user()->id)->get();
//        return view("listCart")->with("mydata" , $data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\cartitem  $cartitem
     * @return \Illuminate\Http\Response
     */
    public function show(cartitem $cartitem)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\cartitem  $cartitem
     * @return \Illuminate\Http\Response
     */
    public function edit(cartitem $cartitem)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\cartitem  $cartitem
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, cartitem $cartitem)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\cartitem  $cartitem
     * @return \Illuminate\Http\Response
     */
    public function destroy(cartitem $cartitem)
    {
        //
    }

    public function showCart()
    {
        $userid=Auth::id();
        $cart=cart::where('user_id','=',$userid)->first();
        $cartitems =cartitem::where('cart_id','=',Auth::user()->id)->get();
        $quantity=[];
        $totalPrice=0;
        $data=[];
        foreach($cartitems as $obj)
        {
            $datamenu=menu::where('id','=',$obj->menu_id)->first();
            $totalPrice=$totalPrice+($datamenu->price * $obj->quantity);
            $quantity[]=$obj->quantity;
            $data[]=$datamenu;
        }
        return view('listcart')
            ->with('data',$data)
            ->with('totalPrice',$totalPrice)
            ->with('quantity',$quantity);
    }


    public function deletecartitem($id)
    {
        $data=cartitem::where('menu_id','=',$id);
        $data->delete();
        return redirect()->back();
    }










}
