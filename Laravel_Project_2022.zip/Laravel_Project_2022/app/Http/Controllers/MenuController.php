<?php

namespace App\Http\Controllers;

use App\Models\cartitem;
use App\Models\menu;
use App\Models\restaurant;
use Illuminate\Http\Request;
use App\Http\Controllers\CartitemController;
use Illuminate\Support\Facades\Auth;

class MenuController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $menu = menu::with('getRestaurant')->get();
        $restaurant = restaurant::with('getMenu')->get();
        return view('testview' , compact('menu' , 'restaurant'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\menu  $menu
     * @return \Illuminate\Http\Response
     */

    public function show(restaurant $restaurant)
    {
        $menu = menu::with('getRestaurant')->where('restaurant_id' , $restaurant->id)->get();
        $restaurant = restaurant::with('getMenu')->where('id' , $restaurant->getMenu->restaurant_id)->get();
        return view('testview' , compact('menu' , 'restaurant'));


//        $menu = menu::with('getRestaurant')->where('restaurant_id' , $menu->getRestaurant->id)->get();
//        $restaurant = restaurant::with('getMenu')->get();
//        return view('testview' , compact('menu' , 'restaurant'));

//         $menu = menu::find($menu->retaurant_id);
//         return view("testview")->with("menu" ,$menu);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\menu  $menu
     * @return \Illuminate\Http\Response
     */
    public function edit(menu $menu)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\menu  $menu
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, menu $menu)
    {

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\menu  $menu
     * @return \Illuminate\Http\Response
     */
    public function destroy(menu $menu)
    {
        //
    }

    public function show1(restaurant $restaurant,Request $request)
    {

        if($request->input('sort') == 'price_acs'){
            return $restaurant->id;
            $menu = menu::with('getRestaurant')->where('restaurant_id' , $restaurant->id)
                ->orderBy('price','asc')
                ->get();
            return view('testview' , compact('menu' , 'restaurant'));

        }elseif($request->input('sort') == 'price_desc'){
            $menu = menu::with('getRestaurant')->where('restaurant_id' , $restaurant->id)
                ->orderBy('price','desc')
                ->get();
        }else{
            $menu = menu::with('getRestaurant')->where('restaurant_id' , $restaurant->id)->get();
        }

        $menu = menu::with('getRestaurant')->where('restaurant_id' , $restaurant->id)->get();
        $restaurant = restaurant::with('getMenu')->where('id' , $restaurant->getMenu->restaurant_id)->get();
        return view('testview' , compact('menu' , 'restaurant'));

    }

    public function search()
    {
       $search_text = $_GET['query'];
        $food = menu::where('name','LIKE', '%'.$search_text.'%')->get();
        return view('searchfood',compact('food'));


    }

    public function checkout(menu $menu)
    {
        $data = menu::find($menu->id);
        return view('menudetail')->with("data", $data);
    }

    public function checkoutcartitem(menu $menu,Request $request )
    {
        $data = menu::find($menu->id);
        $exist=cartitem::where('cart_id','=',Auth::user()->id)->where('menu_id','=',$data->id)->first();
        if($exist)
        {
            $quantity=$exist->quantity+$request->quantity;
            $exist=cartitem::where('cart_id','=',Auth::user()->id)->where('menu_id','=',$data->id)->delete();

            $cart = new cartitem();
            $cart->cart_id=Auth::user()->id;
            $cart->menu_id=$data->id;
            $cart->quantity=$quantity;

            $cart->save();
        }else
        {
            $cart = new cartitem();
            $cart->cart_id=Auth::user()->id;
            $cart->menu_id=$data->id;
            $cart->quantity=$request->quantity;

            $cart->save();
        }


        $qwe=menu::where('restaurant_id',$menu->restaurant_id)->get();
        $res=restaurant::where('id',$menu->restaurant_id)->get();
        return view("testview")
            ->with("menu",$qwe)
        ->with("restaurant",$res);

    }


}
