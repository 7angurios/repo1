<?php

namespace App\Http\Controllers;

use BotMan\BotMan\Messages\Incoming\Answer;

class BotManController extends Controller
{
    public function handle(){
        $botman = app('botman');
        $botman->hears('{message}',function ($botman,$message){

            if($message == 'hi' or $message == 'hey' or $message == 'hello'){
                $this->askName($botman);
            }elseif($message=='hey ') {
                $botman->reply("Hello");

            }
            elseif($message=='by'){
                $botman->reply("Good by");
            }
        });
        $botman->listen();
    }

    public function askName($botman){
        $botman->ask('Hello! What is your Name?',function (Answer $answer){
            $name = $answer->getText();
            $this->say('Nice to meet you '.$name);
            $this->say("If You need any help contact us on our email: admin@gmail.com");
        });
    }
}
