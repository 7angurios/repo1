<?php

namespace App\Http\Controllers;

use App\Models\restaurant;
use App\Models\roles;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\ClientController;

class LoginController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
return view ("login");

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'email' => 'required',
            'password'=>'required',

        ]);

        $credentials = $request->only('email','password');
        //dd($credentials);
        if(Auth::attempt($credentials)){

           if(Auth()->User()->Role_id==1){

               $data = restaurant::where('status',0)->get();
               return view('listrestaurant')->with("mydata" ,$data);


           }
           elseif (Auth()->User()->Role_id==2){


               $data = restaurant::where('cook_id' , Auth::user()->id)->first();

               return view ("CookMain")
                   ->with("mydata",$data);

           }



           elseif (Auth()->User()->Role_id=3){
               return view('adminpage');
           }
        }
        return ("error");


    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\roles  $login
     * @return \Illuminate\Http\Response
     */
    public function show(roles $login)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\roles  $login
     * @return \Illuminate\Http\Response
     */
    public function edit(roles $login)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\roles  $login
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, roles $login)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\roles  $login
     * @return \Illuminate\Http\Response
     */
    public function destroy(roles $login)
    {
        //
    }

    public function logout() {
        Auth::logout();
        return redirect(route('client.create'));
    }


}
