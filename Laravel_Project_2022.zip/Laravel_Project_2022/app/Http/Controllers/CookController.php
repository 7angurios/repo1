<?php

namespace App\Http\Controllers;

use App\Models\menu;
use App\Models\orderitem;
use App\Models\restaurant;
use App\Models\User;
use App\Models\order;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
class CookController extends Controller
{
    public function home()
    {

        $data = restaurant::where('cook_id' , Auth::user()->id)->first();

        return view ("CookMain")
            ->with("mydata",$data);

    }
    public function MenuPage()
    {



        return view ("CookAddMenu");


    }
    public function MyMenu(User $user)
    {

        $data = restaurant::where('cook_id' , Auth::user()->id)->first();

        $menu= menu::select('*')->where('restaurant_id', $data->id)->get();

        return view ("CookMenu")
          ->with("mydata",$menu);

    }
    public function store(Request $request)
    {
        $this->validate($request, [
            'fname' => [
                'required'
            ]
        ]);

        $this->validate($request, [
            'lname' => [
                'required'
            ]
        ]);

        $this->validate($request, [
            'address' => [
                'required'
            ]
        ]);

        $this->validate($request, [
            'contact' => [
                'required',
                'min:8',
                'max:8'
            ]
        ]);

        $validatedData = $request->validate([
            'email' => ['required', 'unique:clients', 'max:255']
        ]);

        $this->validate($request, [
            'password' => [
                'required',
                'min:6'
//                'regex:/^.*(?=.{3,})(?=.*[a-zA-Z])(?=.*[0-9])(?=.*[\d\x])(?=.*[!$#%]).*$/'

            ]
        ]);

        $data = new User();
        $fname = $request->input("fname");
        $lname = $request->input("lname");
        $contact = $request->input("contact");
        $address = $request->input("address");
        $email = $request->input("email");


        $password = bcrypt($request->input("password"));



        $data->lname = $lname;
        $data->fname = $fname;
        $data->contact = $contact;
        $data->address = $address;
        $data->email = $email;
        $data->password = $password;
        $data->Role_iD=2;


        $data->save();

        Auth::login($data);
        $restaurant = new restaurant();
        $restaurant->cook_id = Auth::user()->id;
        $restaurant->status=1;
        $restaurant->save();








        return redirect(route('home'));



    }
    public function MyRest(User $user)
    {
        $data = restaurant::where('cook_id' , $user->id )->first();
       return view ("CookEditRestau")
            ->with("mydata",$data);
    }
    public function CookEditRestau(request $request,User $user)
    {

        $data = restaurant::where('cook_id' , $user->id )->first();



        $data->name = $request->input("name");
        $data->image = $request->input("image");
        $data->email = $request->input("email");
        $data->number = $request->input("number");
        $data->address = $request->input("address");


        $data->save();


       return view ("CookMain")
            ->with("mydata",$data);

    }
    public function AddItem(request $request,User $user)
    {


        $rest = restaurant::where('cook_id' , $user->id )->first();




        $data = new menu();
        $name = $request->input("name");
        $price = $request->input("price");
        $description = $request->input("description");
        $category = $request->input("category");
        $cuisine = $request->input("cuisine");
        $image = $request->input("image");



        $data->name = $name;
        $data->price = $price;
        $data->description = $description;
        $data->category = $category;
        $data->cuisine = $cuisine;
        $data->image = $image;
        $data->restaurant_id = $rest->id;

        $data->save();


        return view ("CookMain")
            ->with("mydata",$rest);

    }
    public function CookEdit(menu $menu){


        return view ("CookEditMenu")
            ->with("mydata",$menu);

    }
    public function CookEditMenu(request $request,menu $menu){



        $menu->name = $request->input("name");
        $menu->price = $request->input("price");
        $menu->description = $request->input("description");
        $menu->category = $request->input("category");
        $menu->cuisine = $request->input("cuisine");
        $menu->image = $request->input("image");
        $menu->restaurant_id =$menu->restaurant_id;


        $menu->save();

        return redirect()->route('home');

    }
    public function Myorders(User $user){

        $data = restaurant::where('cook_id' , $user->id )->first();

        $order= order::where('restaurant_id', $data->id)->get();



        return view ("CookOrders")
            ->with("mydata",$order);


    }
    public function orderdetail(order $order){


        $orderitem=orderitem::where('orders_id', $order->id)->get(); //good
    $data=[];
    $quantity=[];
    foreach($orderitem as $obj)
    {
        $items=menu::where('id', $obj->menu_id)->first();
        $data[]=$items;
        $quantity[]=$obj->quantity;
    }

    return  view ("CookOrderDetails")
        ->with('mydata',$data)
        ->with('quantity',$quantity);


}
    public function CookDeleteitem(menu $menu)
    {

        $data=menu::where('id','=',$menu->id);
        $data->delete();
        return redirect()->back();

    }
    public function Accepted(order $order){

        $order->status ="Accepted";
        $order->save();
        return redirect()->back();
    }
    public function Preparing(order $order ){
        $order->status ="Preparing";
        $order->save();
        return redirect()->back();
    }
    public function Delivering(order $order ){
        $order->status ="Delivering";
        $order->save();
        return redirect()->back();
    }
    public function Delivered(order $order){
        $order->status ="Delivered";
        $order->save();
        return redirect()->back();
    }

}


