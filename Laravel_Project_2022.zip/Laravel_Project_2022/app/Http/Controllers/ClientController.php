<?php

namespace App\Http\Controllers;

use App\Models\cart;
use App\Models\client;
use App\Models\restaurant;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\validate;
use \Illuminate\Foundation\Auth\AuthenticatesUsers;
use App\Http\Controllers\CartController;


use function Ramsey\Uuid\v1;


class ClientController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = client::all();
        return view("roles")->with("mydata" , $data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('login');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'fname' => [
                'required'
            ]
        ]);

        $this->validate($request, [
            'lname' => [
                'required'
            ]
        ]);

        $this->validate($request, [
            'address' => [
                'required'
            ]
        ]);

        $this->validate($request, [
            'contact' => [
                'required',
                'min:8',
                'max:8'
            ]
        ]);

        $validatedData = $request->validate([
            'email' => ['required', 'unique:users', 'max:255']
        ]);

        $this->validate($request, [
            'password' => [
                'required',
                'min:6'
//                'regex:/^.*(?=.{3,})(?=.*[a-zA-Z])(?=.*[0-9])(?=.*[\d\x])(?=.*[!$#%]).*$/'

            ]
        ]);


        $data = new User();
        $fname = $request->input("fname");
        $lname = $request->input("lname");
        $contact = $request->input("contact");
        $address = $request->input("address");
        $email = $request->input("email");

        $password = bcrypt($request->input("password"));



        $data->lname = $lname;
        $data->fname = $fname;
        $data->contact = $contact;
        $data->address = $address;
        $data->email = $email;
        $data->password = $password;
        $data->Role_iD=1;

        $data->save();

        Auth::login($data);
        $cart = new cart();
        $cart->user_id = Auth::user()->id;
        $cart->save();

        $data = restaurant::where('status',0)->get();
        return view('listrestaurant')->with("mydata" ,$data);

    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\client  $client
     * @return \Illuminate\Http\Response
     */
    public function show(client $client)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\client  $client
     * @return \Illuminate\Http\Response
     */
    public function edit(client $client)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\client  $client
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, client $client)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\client  $client
     * @return \Illuminate\Http\Response
     */
    public function destroy(client $client)
    {
        //
    }


}
