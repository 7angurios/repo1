<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ClientController;
use App\Http\Controllers\RestaurantController;
use App\Http\Controllers\MenuController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\CartController;
use \App\Http\Controllers\LoginController;
use \App\Http\Controllers\CookController;
use \App\Http\Controllers\OrderitemController;
use \App\Http\Controllers\BotManController;

use App\Http\Controllers\CartitemController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/', function () {
    return view('homepage');
})->name("welcome");

Route::get('/signupcook', function () {
    return view('addCook');
})->name("signupcook");

Route::resource('client' ,ClientController::class );

Route::get('/signup', function () {
    return view('addclient');
})->name("signup");

Route::resource('cook', CookController::class);

Route::post('addcook',[CookController::class,'store'])->name("storecook");

Route::resource('login' ,LoginController::class );


Route::get('logout',[LoginController::class,'logout'])->name("logout");


//admim



Route::group(['middleware' => ['auth','role:3']], function() {

    Route::get('adminpage', [AdminController::class, 'adminpage'])->name("adminpage");
    Route::get('request', [AdminController::class, 'request'])->name("request");
    Route::post('accept/{restaurant}', [AdminController::class, 'accept'])->name("accept");
    Route::get('request2', [AdminController::class, 'request2'])->name("request2");
    Route::post('reject/{restaurant}', [AdminController::class, 'reject'])->name("reject");
    Route::resource('admin', AdminController::class);
    Route::post('adminlog', [AdminController::class, 'adminlog'])->name("adminlog");
    Route::post('AdminEditRerestau/{restaurant}', [AdminController::class, 'uprestau'])->name("uprestau");
    Route::post('AdminUpdateRerestau/{restaurant}', [AdminController::class, 'subupdate'])->name("subupdate");
    Route::post('AdminDeleteRerestau/{restaurant}', [AdminController::class, 'deleteresto'])->name("deleteresto");
    Route::post('AdminEditClient/{user}', [AdminController::class, 'upclient'])->name("upclient");
    Route::post('AdminUpdateClient/{user}', [AdminController::class, 'subupdateClient'])->name("subupdateClient");
    Route::post('AdminDeleteClient/{user}', [AdminController::class, 'deleteclient'])->name("deleteclient");
    Route::get('listrest', [AdminController::class, 'listrest'])->name("listrest");
    Route::get('listclient', [AdminController::class, 'listclient'])->name("listclient");




});


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//cook

Route::group(['middleware' => ['auth','role:2']], function() {
    Route::get('MyRest/{user}', [CookController::class, 'MyRest'])->name("MyRest");
    Route::post('CookEditRestau/{user}', [CookController::class, 'CookEditRestau'])->name("CookEditRestau");
    Route::get('MenuPage', [CookController::class, 'MenuPage'])->name('MenuPage');
    Route::post('AddItem/{user}', [CookController::class, 'AddItem'])->name("AddItem");
    Route::get('Mymenu/{user}', [CookController::class, 'Mymenu'])->name('Mymenu');
    Route::get('Myorders/{user}', [CookController::class, 'Myorders'])->name('Myorders');
    Route::get('home/cook', [CookController::class, 'home'])->name('home');
    Route::post('CookEdit/{menu}', [CookController::class, 'CookEdit'])->name("CookEdit");
    Route::post('CookEditMenu/{menu}', [CookController::class, 'CookEditMenu'])->name("CookEditMenu");
    Route::get('orderdetail/{order}', [CookController::class, 'orderdetail'])->name('orderdetail');
    Route::delete('CookDeleteitem/{menu}',[CookController::class,'CookDeleteitem'])->name('CookDeleteitem');

    Route::get('Accepted/{order}', [CookController::class, 'Accepted'])->name('Accepted');
    Route::get('Preparing/{order}', [CookController::class, 'Preparing'])->name('Preparing');
    Route::get('Delivering/{order}', [CookController::class, 'Delivering'])->name('Delivering');
    Route::get('Delivered/{order}', [CookController::class, 'Delivered'])->name('Delivered');
});



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//cart

Route::group(['middleware' => ['auth','role:1']], function() {


    Route::get('getid', [CartController::class, 'getid'])->name('getid');
    Route::resource('productcart', CartController::class);
    Route::get('getid', [CartController::class, 'getid'])->name('getid');

    Route::get('/addtocart', function () {
        return view('addtocart');
    })->name("addtocart");
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//cart item
    Route::resource('cartitem', CartitemController::class);
    Route::get('showCart/{user}', [CartitemController::class, 'showCart'])->name("showCart");
    Route::delete('/deletecartitem/{menu}',[CartitemController::class,'deletecartitem'])->name('deletecartitem');

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//menu
    Route::post('checkoutcartitem/{menu}', [MenuController::class, 'checkoutcartitem'])->name("checkoutcartitem");
    Route::get('restaurantdetai/{restaurant}', [MenuController::class, 'show1'])->name('show1');
    Route::post('checkoutcartitem/{menu}', [MenuController::class, 'checkoutcartitem'])->name("checkoutcartitem");
    Route::post('checkout/{menu}', [MenuController::class, 'checkout'])->name("checkout");
    Route::get('search', [MenuController::class, 'search'])->name('search');
    Route::resource('menu', MenuController::class);

//resto

    Route::get('restaurantdetail/{id}', [RestaurantController::class, 'restaurantdetail'])->name('restaurantdetail');
    Route::get('searchrestaurant', [RestaurantController::class, 'searchrestaurant'])->name('searchrestaurant');
    Route::resource('restaurant', RestaurantController::class);

/////order item
    Route::resource('orderitem' ,OrderitemController::class);
    Route::get('orderitems',[OrderitemController::class,'orderitems'])->name("orderitems");
    Route::get('showOrderHistory',[OrderitemController::class,'showOrderHistory'])->name("showOrderHistory");
////bot
    Route::get('/bot', function () {
        return view('botman');
    });

    Route::get('botman' , [BotManController::class ,'handle'])->name('handle');
    Route::post('botman' , [BotManController::class ,'handle'])->name('handle1');
});


