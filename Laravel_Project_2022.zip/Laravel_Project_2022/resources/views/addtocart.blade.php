<p>User id: {{Auth::user()->id}}</p>

<p>Name akel : {{$data->name}}</p>

<p>Menu id : {{$data->id}}</p>


