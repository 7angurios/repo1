<style>
    footer{
        display: flex;
        justify-content: center;
        align-items: center;
        padding: 1rem 2rem;
        width: 100%;
        background-color: #262626;
        color: white;
    }
</style>
<footer>
    <div>
        &copy;copyright 2022
        <p>
            Designed by the members
        </p>
    </div>
</footer>
