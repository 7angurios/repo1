<html><head>
    <title>Food delivery system </title>
    <meta name="csrf-token" content="c9MfTg8AtUxgeNXL4QDyWBwPW4UNDvzFsvjZakZ9">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <style>
        *{
            padding: 0;
            margin: 0;

            box-sizing: border-box;

            font-family: 'Baloo Bhai 2', cursive;
        }
        nav{
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 2rem;

            background-color: #262626;

            position:fixed;
            top:0;
            left: 0;
            width: 100%;
            z-index: 9999;
            overflow: hidden;

        }

        ul{
            display: flex;
            list-style: none;
            /* text-align: center; */
            color: #fff;
            gap: 2rem;
            position:fixed;
            right:0;
            padding-right: 15px;

        }
        nav a{
            color: white;
            text-decoration: none;

        }
        a:hover {
            background-color: rgb(22, 22, 94);
            border-radius: 10px;
            padding: 10px;
        }



        img{
            width: 100%;

            object-fit: cover;
            object-position: center;
        }
        header{
            background: linear-gradient(rgba(0,0,0,0.5),rgba(0,0,0,0.2)),url(https://images.unsplash.com/photo-1589302168068-964664d93dc0?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1887&q=80);
            background-position: center;
            background-size: cover;

            height: 100vh;
        }

        #mobile ul li{

            justify-content: flex-end;
            padding: -25px 5px;
            margin: -38px 0;
            font-size: 1rem;
            color: white;
        }
        #mobile ul li a{
            display: flex;
            text-decoration: none;
            color: white;
        }

        a:hover{
            background-color: rgb(22, 22, 94);
            border-radius: 16px;
            padding: 6px 8px 6px 8px;
            margin: -7px;
        }
        header{

            background: linear-gradient(rgba(0,0,0,0.5),rgba(0,0,0,0.2)),url(https://images.unsplash.com/photo-1589302168068-964664d93dc0?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1887&q=80);
            background-position: center;
            background-size: cover;

            height: 180vh;
        }

        }
        .title{
            text-align: center;
            width: 100%;
            color: yellow;

        }

        .heading>h3{
            font-weight: 600;
            font-size: 22px;
            letter-spacing: 5px;
        }

        .card img{
            position: relative;
            width: 100%;
            height: 50vh;
            border-radius: 15px 15px 0 0;
        }

        .details-sub h5{
            font-weight: 600;
            font-size: 18px;
        }

        .details p{
            color: #6f6f6f;
            font-size: 15px;
            line-height: 25px;
            align-self: stretch;
        }
        .details button{
            border: none;
            color: #ffffff;
            font-size: 16px;
            font-weight: 600;
            border-radius: 7px;
            width: 180px;
        }



        #about{
            padding: 25px 0;
        }
        .about_row{
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap;
            padding: 0 100px;
        }
        .about_column{
            flex: 1;
        }
        #btn1{
            margin-top: 20px;
            padding: 10px 10px;
            border-radius: 15px;
        }
        .about_column img{
            width: 500px;
            height: 500px;
            border-radius: 50%;
            object-fit: fill;
            margin: auto;
        }
        .title{
            color: #373333;
            margin-bottom: 30px;
            padding: 50px 0 30px 0;
            text-align: center;
        }


        form{
            width: 450px;
            background-color: white;

            box-shadow: 0 0 20px 0 rgb(213, 212, 210);
            margin: auto;
            margin-top: -20px;
            margin-bottom: 10px;
            border-radius: 20px;
        }


        textarea{
            height: 150px;
            padding-top: 10px;
        }

        button{
            background-color: rgb(22, 22, 94);
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover{
            background-color: rgb(94, 158, 61);
        }

    </style>

</head>

<body>
<div class="container">

    <style>


        *{
            padding: 0;
            margin: 0;

            box-sizing: border-box;

            font-family: 'Baloo Bhai 2', cursive;
        }
        nav{
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 2rem;

            background-color: #262626;

            position:fixed;
            top:0;
            left: 0;
            width: 100%;
            z-index: 9999;
            overflow: hidden;

        }

        ul{
            display: flex;
            list-style: none;
            /* text-align: center; */
            color: #fff;
            gap: 2rem;
            position:fixed;
            right:0;
            padding-right: 15px;

        }
        nav a{
            color: white;
            text-decoration: none;

        }
        a:hover{
            background-color: rgb(22, 22, 94);
            border-radius: 10px;
            padding: 10px;
        }
        .logo{
            justify-content: flex-start;
            align-items: flex-start;
            font-size: 2rem;
            color: #fff;

            margin-right: 700px;

        }




        @media screen and (max-width:768px) {
            #mobile{
                display: block;
            }
            #navbar{
                display: none;

            }

        }
        button{
            background-color: rgb(22, 22, 94);
            color: white;
            border: none;
            cursor: pointer;
        }

    </style>

@include('header')

    <div id="about">
        <h1 class="title">About us</h1>
        <div class="about_row">
            <div class="about_column">
                <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Laboriosam voluptate aperiam id saepe natus tempore adipisci neque incidunt vel nam, distinctio, eos labore cupiditate assumenda doloremque. Assumenda illo delectus aliquid libero, quisquam vero facere molestias neque similique, aperiam dolores ex mollitia nobis nostrum blanditiis autem qui itaque quos, nisi dolore.</p>
                <button id="btn1">learn more</button>
            </div>
            <div class="about_column">
                <img src="https://img.freepik.com/free-photo/chef-making-ok-sign-white-background_1368-2804.jpg?w=2000" alt="">
            </div>
        </div>
    </div>
</div>
@include('footer')

</body>
</html>
