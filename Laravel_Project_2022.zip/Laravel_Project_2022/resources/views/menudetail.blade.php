
<!DOCTYPE html>
<html>
<head>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'open sans', sans-serif;
        }

        .container {
            height: 100vh;
            display:flex;
            justify-content: center;
            align-items: center;
        }

        .product {
            text-align: center;
            margin: 0;
            padding: 0;
            border: 1px solid #e2e2e2;
            box-shadow: 1px 1px .5em #d8d8d8;
        }

        .product img {
            display: block;
            overflow: hidden;
            margin: 0;
        }
        .product .content {
            text-align: left;
            display: flex;
            flex-direction: column;
            padding: .8em;
        }

        .product img:hover {
            opacity: 0.9;
        }

        .content h3 {
            text-transform: uppercase;
            margin: 0;
            padding: 0;
        }

        .content span {
            font-size: 1.15rem;
        }

        h3 + span {
            margin-top: .5em;
        }

        .content a {
            color: rgb(69, 67, 67);
            text-decoration: none;
        }
        .content form {
            color: rgb(69, 67, 67);
            text-decoration: none;
        }

        .link {
            display: flex;
            justify-content: space-between;
            background-color: rgb(59, 57, 57);
        }

        .link a {
            width:100%;
            color: #fff;
            padding: 1rem;
            text-decoration: none;
        }

        .link a:hover {
            background-color: rgb(0,0,0);
        }

        .content a:hover{
            color: rgb(0,0,0);
        }

        .link form {
            width:100%;
            color: #fff;
            padding: 1rem;
            text-decoration: none;
        }

        .link form:hover {
            background-color: rgb(0,0,0);
        }

        .content form:hover{
            color: rgb(0,0,0);
        }

        body {
            background-color: whitesmoke;
        }


        .h3name {
            /*margin-top: 20px;*/
            /*text-align: center;*/
            color: #000;
            padding-left: 18px;
            text-transform: uppercase;
            font-size: 25px;
            line-height: 21px;
            text-align: center;

        }

        .cui {
            text-align: right;
            font-size: 18px;
        }

        input {
            position: relative;
            width: 70px;
            height: 30px;
            size: 150px;
        }

    </style>
</head>
<body>
@include('header');
<div class="container">
    <div class="products">

        <form action="{{route('checkoutcartitem',['menu'=>$data])}}" method="post">
            @csrf
            @method('post')
        <div class="product">
            <img src="{{$data->image}}" width="500px" height="500px" alt="">
            <div class="content">

                <h3 class="h3name">{{$data->name}}</h3><br>
                <span>Description : {{$data->description}}</span>
                <span>Price : {{$data->price}} $</span>
                <span>Cuisine : {{$data->cuisine}}</span>
                Quantity :<input type="number" name="quantity"  value="1" min="1">

            </div>

        </div>
            <div class="link">
                <a href="{{ url()->previous() }}">Back</a>

                @if(Auth::check())
                        <button type="submit">Add to cart</button>
                @else<a href="{{route('client.create')}}">Please login to order</a>
                @endif

            </div>
        </div>
</form>
    </div>
</div>


</body>
@include('footer');
</html>




