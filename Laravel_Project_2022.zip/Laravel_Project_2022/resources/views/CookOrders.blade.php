<headr>
    @include('CookNav')
    <br>
    <br>  <br>  <br>
    <br>  <br>

</headr>

<style>

    uul {
        list-style: none;
        margin: 0;
        padding: 0;
        display: -webkit-inline-flex;

    }

    lii {
        display: -webkit-inline-flex;
        background-color: #f4f4f4;
        padding: 10px;
        margin-bottom: 10px;
        border-radius: 5px;
    }
.buttons{
    display: flex;
    data-inline: "true";
    margin:10px 10px  10px 10px 10px;
}
</style>
{{--@include('CookNav')--}}

<uul class="list-group"  >


   @foreach ($mydata as $obj)

        <lii class="list-group-item">
            Order id : {{$obj->id}}
            <br>
            Status : {{ $obj->status }}
            <br>
            Address :{{ $obj->address }}
            <br>
            Total price :{{ $obj->totalprice }}
            <br>
            created_at :{{ $obj->created_at }}
            <br>
            <br>
        </lii>
</uul>
<div class="buttons">


    <lii>
        <form method="get" action="{{route('orderdetail',['order'=>$obj])}}" >
            <button type="submit" value="">Details</button>
        </form>


        <form method="get" action="{{route('Accepted',['order'=>$obj])}}" >
            <button type="submit" value="">Accepted</button>
        </form>

        <form method="get" action="{{route('Preparing',['order'=>$obj])}}" >
            <button type="submit" value="">Preparing</button>
        </form>

        <form method="get" action="{{route('Delivering',['order'=>$obj])}}" >
            <button type="submit" value="">Delivering</button>
        </form>

        <form method="get" action="{{route('Delivered',['order'=>$obj])}}" >
            <button type="submit" value="">Delivered</button>
        </form>

       </lii>
        </div>

        <br>



    @endforeach

      {{-- @foreach ($client as $qwe)

           Name : {{ $qwe->name }}

       @endforeach--}}

</uul>
