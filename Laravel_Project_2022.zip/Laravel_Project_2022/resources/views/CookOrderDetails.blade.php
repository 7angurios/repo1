<head>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <style>
        .empty-cart {
            width: 50vw;
            margin: 0 auto;
            text-align: center;
            font-family: 'Maison Neue';
            font-weight: 300;
        }

        svg {
            max-width: 60%;
            padding: 5rem 3rem;
        }

        .cart {
            background-color: #f8f8f8;
            border: 1px solid #ddd;
            margin: 20px 0;
            padding: 20px;
        }

        .cart h2 {
            color: #333;
            font-size: 18px;
            margin: 0 0 20px;
        }

        .cart table {
            border-collapse: collapse;
            width: 100%;
        }

        .cart table th,
        .cart table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }

        .cart p {
            color: #333;
            font-size: 16px;
            margin: 20px 0 0;
        }


    </style>

</head>

<body>
@include('CookNav');



</body>

<div class="cart">
    <br>
    <br>
    <h1>Order details</h1>
    <br>
    <table>
        <thead>
        <tr>
            <th>item</th>
            <th>Name</th>
            <th>Category</th>

            <th>Cuisine</th>

        </tr>
        </thead>
        <tbody>

        <td>
            @foreach($mydata as $obj)
                <tr>
                    <td><p>{{ $loop->iteration }}</p></td>
                    <td><p>{{$obj->name}}</p></td>
                    <td><p>{{$obj->category}}</p></td>
                    <td><p>{{$obj->cuisine}}</p></td>


                    @csrf
                </tr>
        @endforeach
        </tbody>

    </table>
    @foreach($quantity as $qty)
        <p>Order {{$loop->iteration}} => Quantity : {{$qty}}</p>
    @endforeach


</div>
<button href="#" onclick="javascript:window.history.back(-1);return false;">Back</button>


