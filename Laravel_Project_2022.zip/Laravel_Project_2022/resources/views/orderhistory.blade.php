<style>

    ul {
        list-style: none;
        margin: 0;
        padding: 0;
    }

    li {
        background-color: #f4f4f4;
        padding: 10px;
        margin-bottom: 10px;
        border-radius: 5px;
    }

</style>

<ul class="list-group">
    @foreach ($showOrders as $item)
        <li class="list-group-item">Order :{{ $loop->iteration }}:</li>
        <li class="list-group-item">First Name : {{ $item->fname }}</li>
        <li class="list-group-item">Last Name : {{ $item->lname }}</li>
        <li class="list-group-item">Restaurant :{{ $item->name }}</li>
        <li class="list-group-item">Status :{{ $item->status }}</li>
        <li class="list-group-item">Total price :{{ $item->totalprice }}</li>
        <br>
    @endforeach
</ul>

<button href="#" onclick="javascript:window.history.back(-1);return false;">Back</button>
