

<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        * {
            padding: 0px;
            margin: 0%;
            box-sizing: border-box;
        }

        .countainer {
            font-family: Arial, Helvetica, sans-serif;
            background-color:  #4d72ea;
            width: 100%;
            height: 70px;
            /* padding: 1rem; */
            display: flex;
            flex-direction: row-reverse;
            align-items: center;
            justify-content: space-around;
        }

        a {
            text-decoration: none;
        }

        li {
            list-style: none;
        }

        .pages {
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            align-items: flex-start;
            margin-top: 5px;
            font-size: 22px;
        }

        .link {
            color: whitesmoke;
            margin: 0%;
            /* padding: 0%; */
            padding: 0 .3rem;
        }

        .page:hover {
            border-bottom: #f5f5f5 solid 1px;
            padding-bottom: 10px;
        }




        .logo {
            color: seashell;
            background-color: blue;
            padding: 6px;
            margin-bottom: 5px;
            border-radius: 3px;
            font-weight: bold;
        }

        .logo,
        .search {
            display: none;
        }

        @media (min-width:426px) {

            .search,
            .logo {
                display: block;
            }

            .search-box {
                height: 28px;
                font-size: 18px;
                border: none;
                padding: 5px 10px;
                border-radius: 3px;
            }

            .link {
                padding: 0px 1rem;
            }
        }
        .styled-table {
            border-collapse: collapse;
            margin: 0px;
            margin-top: 50px;
            font-size: 0.9em;
            font-family: sans-serif;
            width: 100%;
            min-width: 400px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
        }
        .styled-table thead tr {
            background-color: #4d72ea;
            color: #ffffff;
            text-align: left;
        }
        .styled-table th,
        .styled-table td {
            padding: 12px 15px;
        }
        .styled-table tbody tr {
            border-bottom: 1px solid #dddddd;
        }

        .styled-table tbody tr:nth-of-type(even) {
            background-color: #f3f3f3;
        }

        .styled-table tbody tr:last-of-type {
            border-bottom: 2px solid #4d72ea;
        }
        .styled-table tbody tr.active-row {
            font-weight: bold;
            color: #4d72ea;
        }
    </style>


</head>
<body>
<nav>
    <div class="countainer">
        <ul class="pages">
            <a href="{{route('adminpage')}}" class="link link1">
                <li class="page active page1">Home</li>
            </a>
            <a href="{{route('listrest')}}" class="link link2">
                @csrf
                @method('post')
                <li class="page page2">Restaurants</li>
            </a>
            <a href="{{route('listclient')}}" class="link link2">
                @csrf
                @method('post')
                <li class="page page2">Clients</li>
            </a>
            <a href="{{route('request')}}" class="link link2">
                <li class="page page2">Pending</li>
            </a>
            <a href="{{route('request2')}}" class="link link2">
                <li class="page page2">Accept</li>
            </a>

            <a href="{{route('logout')}}" class="link link2">
                <li class="page page2">Logout</li>
            </a>

        </ul>
        <p class="search">
            <input
                class="search-box"
                type="search"
                name="search"
                id="search"
                placeholder="Search..."
            />
        </p>
        <p class="logo">Admin page</p>
    </div>

</nav>



</body>
