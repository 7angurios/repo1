
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <link href='http://fonts.googleapis.com/css?family=Holtwood+One+SC' rel='stylesheet' type='text/css'>

    <style>
        .card {
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
            max-width: 300px;
            margin: auto;
            text-align: center;
            font-family: arial;


            display: grid;
            position: relative;
            grid-template-rows: auto 1fr;
            border-radius: 15px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            margin: 10px 20px;
        }
        }

        .price {
            color: grey;
            font-size: 22px;
        }

        .card button {
            border: none;
            outline: 0;
            padding: 12px;
            color: white;
            background-color: #000;
            text-align: center;
            cursor: pointer;
            width: 100%;
            font-size: 18px;
        }

        .card button:hover {
            opacity: 0.7;
        }

        img {
            width: 300px;
            height: 300px;
        }



        /*            -----------------------------*/
        /*            -----------------------------*/
        /*            -----------------------------*/
        /*            -----------------------------*/
        /*            -----------------------------*/
        body {
            background: url(../images/bg.png);
        }
        .site {
            font-family: 'Holtwood One SC', sans-serif;
        }
        .text-logo {
            font-family: 'Holtwood One SC', sans-serif;
            color: #e7480f;
            text-shadow: 2px 2px #ffd301;
            font-size: 50px;
            padding: 40px 0px;
            text-align: center;
        }
        .text-logo span {
            color: #ffd301;
            text-shadow: 0px 0px #ffd301;
        }
        .nav {
            margin-bottom: 40px;
        }
        .nav-link {
            color: #eee;
            font-size: 18px;
            text-shadow: 2px 2px #333;
            cursor: pointer;
        }
        .nav-link.active {
            background-color: #e7480f !important;
        }
        .nav-link:hover {
            color: #e7480f;
            background-color: #eee;
        }
        .img-thumbnail {
            position: relative;
            margin-bottom: 20px;
        }
        .img-thumbnail img {
            background: #ffd301;
            width: 100%;
        }
        .img-thumbnail .price {
            background: #5cb85c;
            box-shadow: 0 1px rgba(0,0,0,0.2);
            -moz-box-shadow: 0 1px rgba(0,0,0,0.2);
            -webkit-box-shadow: 0 1px rgba(0,0,0,0.2);
            color: #fff;
            text-shadow: 2px 2px #333;
            position: absolute;
            right: -10px;
            top: 16px;
            padding: 5px 10px;
            font-size: 20px;
            border-radius: 3px;
        }
        .img-thumbnail .price:before {
            border: 4px solid transparent;
            border-bottom: 4px solid #4a934a;
            border-left: 4px solid #4a934a;
            content: "";
            position: absolute;
            right: 1px;
            top: -8px;
        }
        .img-thumbnail .caption {
            padding: 9px;
        }
        .img-thumbnail .caption h4 {
            color: #e7480f;
            font-size: 18px;
        }
        .img-thumbnail .btn-order {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            color: #fff;
            background-color: #e7480f;
            text-shadow: 2px 2px #333;
        }
        .img-thumbnail .btn-order:hover,
        .img-thumbnail .btn-order:focus {
            color: #fff;
            background-color: #c13c0d;
        }






    </style>
</head>
<body>

<div class="tab-content">

    @foreach($mydata as $obj)

        <div class="card">
            <h1 style="text-align:center"> <span class="glyphicon glyphicon-cutlery"></span> {{$obj->name}} <span class="glyphicon glyphicon-cutlery"></span></h1>
            <img src="{{$obj->image}} " style="width: 100%"><br>
            <a href="{{route('restaurant.show',['restaurant'=>$obj])}}">View</a>

        </div>
    @endforeach
</div>



</body>
</html>
