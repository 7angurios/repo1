
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        * {
            padding: 0px;
            margin: 0%;
            box-sizing: border-box;
        }

        a {
            text-decoration: none;
        }

        li {
            list-style: none;
        }

        .styled-table {
            border-collapse: collapse;
            margin: 0px;
            margin-top: 50px;
            font-size: 0.9em;
            font-family: sans-serif;
            width: 100%;
            min-width: 400px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
        }
        .styled-table thead tr {
            background-color: #4d72ea;
            color: #ffffff;
            text-align: left;
        }
        .styled-table th,
        .styled-table td {
            padding: 12px 15px;
        }
        .styled-table tbody tr {
            border-bottom: 1px solid #dddddd;
        }

        .styled-table tbody tr:nth-of-type(even) {
            background-color: #f3f3f3;
        }

        .styled-table tbody tr:last-of-type {
            border-bottom: 2px solid #4d72ea;
        }
        .styled-table tbody tr.active-row {
            font-weight: bold;
            color: #4d72ea;
        }
        .button{
            background: #FF4742;
            border: 1px solid #FF4742;
            border-radius: 6px;
            box-shadow: rgba(0, 0, 0, 0.1) 1px 2px 4px;
            box-sizing: border-box;
            color: #FFFFFF;
            cursor: pointer;
            display: inline-block;
            font-family: nunito,roboto,proxima-nova,"proxima nova",sans-serif;
            font-size: 16px;
            font-weight: 800;
            line-height: 16px;
            min-height: 40px;
            outline: 0;
            padding: 12px 14px;
            text-align: center;
            text-rendering: geometricprecision;
            text-transform: none;
            user-select: none;
            -webkit-user-select: none;
            touch-action: manipulation;
            vertical-align: middle;
        }

        .button:hover,
        .button:active {
            background-color: initial;
            background-position: 0 0;
            color: #FF4742;
        }

        .button:active {
            opacity: .5;
        }
        button {
            color: red;
            border: none;
            font-size: 16px;
            border-radius: 8px;
            padding: 10px 15px;
            cursor:pointer;
        }
    </style>

    <?php echo $__env->make('adminNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
<br><br>
<table class="styled-table">
    <thead>
    <tr>
        <th>ID</th>
        <th>NAME</th>
        <th>IMAGE</th>
        <th>PENDING</th>
        <th>EMAIL</th>
        <th>NUMBER</th>
        <th>ADDRESS</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $mydata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr class="active-row">
        <td><?php echo e($obj->id); ?></td>
        <td><?php echo e($obj->name); ?></td>
        <td><img src="<?php echo e($obj->image); ?>" width="100"></td>
        <td>
            <form action="<?php echo e(route('accept',['restaurant'=>$obj])); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="container">
                    <button onClick="" class="cancel">Accept</button>
                </div>
            </form>
        </td>

        <td><?php echo e($obj->email); ?></td>
        <td><?php echo e($obj->number); ?></td>
        <td><?php echo e($obj->address); ?></td>

    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <tr>
    </tr>
    </tbody>
</table>


</body>

<?php /**PATH C:\xamppp\htdocs\Laravel_Project_2022\resources\views/adminrequest.blade.php ENDPATH**/ ?>