<style>


    *{
        padding: 0;
        margin: 0;

        box-sizing: border-box;

        font-family: 'Baloo Bhai 2', cursive;
    }
    nav{
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 1rem 2rem;

        background-color: #262626;

        position:fixed;
        top:0;
        left: 0;
        width: 100%;
        z-index: 9999;
        overflow: hidden;

    }

    ul{
        display: flex;
        list-style: none;
        /* text-align: center; */
        color: #fff;
        gap: 2rem;
        position:fixed;
        right:0;
        padding-right: 15px;

    }
    nav a{
        color: white;
        text-decoration: none;

    }
    a:hover{
        background-color: rgb(22, 22, 94);
        border-radius: 10px;
        padding: 10px;
    }
    .logo{
        justify-content: flex-start;
        align-items: flex-start;
        font-size: 2rem;
        color: #fff;

        margin-right: 700px;

    }




    @media screen and (max-width:768px) {
        #mobile{
            display: block;
        }
        #navbar{
            display: none;

        }

    }
    button{
        background-color: rgb(22, 22, 94);
        color: white;
        border: none;
        cursor: pointer;
    }

</style>

</style>
<header>
    <nav id="navbar">
        <div class="logo"><span>Welcome Back</span></div>

        <ul>


            <li><a href="<?php echo e(route('client.create')); ?>">Login</a></li>
        </ul>

    </nav>


</header>

<?php /**PATH C:\xamppp\htdocs\Laravel_Project_2022\resources\views/headerAdmin.blade.php ENDPATH**/ ?>