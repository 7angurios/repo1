
<!DOCTYPE html>
<html>
<head>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'open sans', sans-serif;
        }

        .container {
            height: 100vh;
            display:flex;
            justify-content: center;
            align-items: center;
        }

        .product {
            text-align: center;
            margin: 0;
            padding: 0;
            border: 1px solid #e2e2e2;
            box-shadow: 1px 1px .5em #d8d8d8;
        }

        .product img {
            display: block;
            overflow: hidden;
            margin: 0;
        }
        .product .content {
            text-align: left;
            display: flex;
            flex-direction: column;
            padding: .8em;
        }

        .product img:hover {
            opacity: 0.9;
        }

        .content h3 {
            text-transform: uppercase;
            margin: 0;
            padding: 0;
        }

        .content span {
            font-size: 1.15rem;
        }

        h3 + span {
            margin-top: .5em;
        }

        .content a {
            color: rgb(69, 67, 67);
            text-decoration: none;
        }
        .content form {
            color: rgb(69, 67, 67);
            text-decoration: none;
        }

        .link {
            display: flex;
            justify-content: space-between;
            background-color: rgb(59, 57, 57);
        }

        .link a {
            width:100%;
            color: #fff;
            padding: 1rem;
            text-decoration: none;
        }

        .link a:hover {
            background-color: rgb(0,0,0);
        }

        .content a:hover{
            color: rgb(0,0,0);
        }

        .link form {
            width:100%;
            color: #fff;
            padding: 1rem;
            text-decoration: none;
        }

        .link form:hover {
            background-color: rgb(0,0,0);
        }

        .content form:hover{
            color: rgb(0,0,0);
        }

        body {
            background-color: whitesmoke;
        }


        .h3name {
            /*margin-top: 20px;*/
            /*text-align: center;*/
            color: #000;
            padding-left: 18px;
            text-transform: uppercase;
            font-size: 25px;
            line-height: 21px;
            text-align: center;

        }

        .cui {
            text-align: right;
            font-size: 18px;
        }

        input {
            position: relative;
            width: 70px;
            height: 30px;
            size: 150px;
        }

    </style>
</head>
<body>
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<div class="container">
    <div class="products">

        <form action="<?php echo e(route('checkoutcartitem',['menu'=>$data])); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('post'); ?>
        <div class="product">
            <img src="<?php echo e($data->image); ?>" width="500px" height="500px" alt="">
            <div class="content">

                <h3 class="h3name"><?php echo e($data->name); ?></h3><br>
                <span>Description : <?php echo e($data->description); ?></span>
                <span>Price : <?php echo e($data->price); ?> $</span>
                <span>Cuisine : <?php echo e($data->cuisine); ?></span>
                Quantity :<input type="number" name="quantity"  value="1" min="1">

            </div>

        </div>
            <div class="link">
                <a href="<?php echo e(url()->previous()); ?>">Back</a>

                <?php if(Auth::check()): ?>
                        <button type="submit">Add to cart</button>
                <?php else: ?><a href="<?php echo e(route('client.create')); ?>">Please login to order</a>
                <?php endif; ?>

            </div>
        </div>
</form>
    </div>
</div>


</body>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
</html>




<?php /**PATH C:\xamppp\htdocs\Laravel_Project_2022\resources\views/menudetail.blade.php ENDPATH**/ ?>