<style>

    ul {
        list-style: none;
        margin: 0;
        padding: 0;
    }

    li {
        background-color: #f4f4f4;
        padding: 10px;
        margin-bottom: 10px;
        border-radius: 5px;
    }

</style>

<ul class="list-group">
    <?php $__currentLoopData = $showOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="list-group-item">Order :<?php echo e($loop->iteration); ?>:</li>
        <li class="list-group-item">First Name : <?php echo e($item->fname); ?></li>
        <li class="list-group-item">Last Name : <?php echo e($item->lname); ?></li>
        <li class="list-group-item">Restaurant :<?php echo e($item->name); ?></li>
        <li class="list-group-item">Status :<?php echo e($item->status); ?></li>
        <li class="list-group-item">Total price :<?php echo e($item->totalprice); ?></li>
        <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>

<button href="#" onclick="javascript:window.history.back(-1);return false;">Back</button>
<?php /**PATH C:\xamppp\htdocs\Laravel_Project_2022\resources\views/orderhistory.blade.php ENDPATH**/ ?>