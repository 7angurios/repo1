<?php echo e($mydata->name); ?>

<?php /**PATH C:\xamppp\htdocs\Laravel_Project_2022\resources\views/zzz.blade.php ENDPATH**/ ?>