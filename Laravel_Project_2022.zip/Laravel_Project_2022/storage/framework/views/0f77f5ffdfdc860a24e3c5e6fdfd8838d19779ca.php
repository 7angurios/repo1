<style>


    *{
        padding: 0;
        margin: 0;

        box-sizing: border-box;

        font-family: 'Baloo Bhai 2', cursive;
    }
    nav{
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 1rem 2rem;

        background-color: #262626;

        position:fixed;
        top:0;
        left: 0;
        width: 100%;
        z-index: 9999;
        overflow: hidden;

    }

    ul{
        display: flex;
        list-style: none;
        /* text-align: center; */
        color: #fff;
        gap: 2rem;
        position:fixed;
        right:0;
        padding-right: 15px;

    }
    nav a{
        color: white;
        text-decoration: none;

    }
    a:hover{
        background-color: rgb(22, 22, 94);
        border-radius: 10px;
        padding: 10px;
    }
    .logo{
        justify-content: flex-start;
        align-items: flex-start;
        font-size: 2rem;
        color: #fff;

        margin-right: 700px;

    }




    @media screen and (max-width:768px) {
        #mobile{
            display: block;
        }
        #navbar{
            display: none;

        }

    }


</style>

</style>
<header>
    <nav id="navbar">
        <div class="logo"><span>Welcome to our page</span></div>
        <ul>





            <?php echo csrf_field(); ?>
            <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
            <li><a href="<?php echo e(route('MyRest',['user'=>  Auth::user() ])); ?>">Edit My Restaurant</a></li>



            <li><a href="<?php echo e(route('MenuPage',['user'=>  Auth::user() ])); ?>">Add Items To Menu</a></li>


            <li><a href="<?php echo e(route('Mymenu',['user'=>  Auth::user() ])); ?>">My Menu</a></li>

            <li><a href="<?php echo e(route('Myorders',['user'=>  Auth::user() ])); ?>">Orders</a></li>


            <?php if(Auth::check()): ?>
                <li><a href="<?php echo e(route('logout')); ?>">logout</a></li>
            <?php else: ?><li><a href="<?php echo e(route('client.create')); ?>">Login</a></li>
            <?php endif; ?>
            
        </ul>
    </nav>


</header>

<?php /**PATH C:\xamppp\htdocs\Laravel_Project_2022\resources\views/CookNav.blade.php ENDPATH**/ ?>