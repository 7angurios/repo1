<head>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <style>
        .empty-cart {
            width: 50vw;
            margin: 0 auto;
            text-align: center;
            font-family: 'Maison Neue';
            font-weight: 300;
        }

        svg {
            max-width: 60%;
            padding: 5rem 3rem;
        }

        .cart {
            background-color: #f8f8f8;
            border: 1px solid #ddd;
            margin: 20px 0;
            padding: 20px;
        }

        .cart h2 {
            color: #333;
            font-size: 18px;
            margin: 0 0 20px;
        }

        .cart table {
            border-collapse: collapse;
            width: 100%;
        }

        .cart table th,
        .cart table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }

        .cart p {
            color: #333;
            font-size: 16px;
            margin: 20px 0 0;
        }


    </style>

</head>

<body>
<?php echo $__env->make('CookNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;



</body>

<div class="cart">
    <br>
    <br>
    <h1>Order details</h1>
    <br>
    <table>
        <thead>
        <tr>
            <th>item</th>
            <th>Name</th>
            <th>Category</th>

            <th>Cuisine</th>

        </tr>
        </thead>
        <tbody>

        <td>
            <?php $__currentLoopData = $mydata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><p><?php echo e($loop->iteration); ?></p></td>
                    <td><p><?php echo e($obj->name); ?></p></td>
                    <td><p><?php echo e($obj->category); ?></p></td>
                    <td><p><?php echo e($obj->cuisine); ?></p></td>


                    <?php echo csrf_field(); ?>
                </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>
    <?php $__currentLoopData = $quantity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p>Order <?php echo e($loop->iteration); ?> => Quantity : <?php echo e($qty); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


</div>

<?php /**PATH C:\xamppp\htdocs\Laravel_Project_2022\resources\views/CookOrderDetails.blade.php ENDPATH**/ ?>