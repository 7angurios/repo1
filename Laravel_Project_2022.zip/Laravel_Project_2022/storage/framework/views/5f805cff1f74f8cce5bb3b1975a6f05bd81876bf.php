<headr>
    <?php echo $__env->make('CookNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <br>
    <br>  <br>  <br>
    <br>  <br>

</headr>

<style>

    uul {
        list-style: none;
        margin: 0;
        padding: 0;
        display: -webkit-inline-flex;

    }

    lii {
        display: -webkit-inline-flex;
        background-color: #f4f4f4;
        padding: 10px;
        margin-bottom: 10px;
        border-radius: 5px;
    }
.buttons{
    display: flex;
    data-inline: "true";
    margin:10px 10px  10px 10px 10px;
}
</style>


<uul class="list-group"  >


   <?php $__currentLoopData = $mydata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <lii class="list-group-item">
            Order id : <?php echo e($obj->id); ?>

            <br>
            Status : <?php echo e($obj->status); ?>

            <br>
            Address :<?php echo e($obj->address); ?>

            <br>
            Total price :<?php echo e($obj->totalprice); ?>

            <br>
            created_at :<?php echo e($obj->created_at); ?>

            <br>
            <br>
        </lii>
</uul>
<div class="buttons">


    <lii>
        <form method="get" action="<?php echo e(route('orderdetail',['order'=>$obj])); ?>" >
            <button type="submit" value="">Details</button>
        </form>


        <form method="get" action="<?php echo e(route('Accepted',['order'=>$obj])); ?>" >
            <button type="submit" value="">Accepted</button>
        </form>

        <form method="get" action="<?php echo e(route('Preparing',['order'=>$obj])); ?>" >
            <button type="submit" value="">Preparing</button>
        </form>

        <form method="get" action="<?php echo e(route('Delivering',['order'=>$obj])); ?>" >
            <button type="submit" value="">Delivering</button>
        </form>

        <form method="get" action="<?php echo e(route('Delivered',['order'=>$obj])); ?>" >
            <button type="submit" value="">Delivered</button>
        </form>

       </lii>
        </div>

        <br>



    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      

</uul>
<?php /**PATH C:\xamppp\htdocs\Laravel_Project_2022\resources\views/CookOrders.blade.php ENDPATH**/ ?>