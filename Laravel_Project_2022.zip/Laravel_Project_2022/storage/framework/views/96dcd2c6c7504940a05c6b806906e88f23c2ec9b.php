
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <link href='http://fonts.googleapis.com/css?family=Holtwood+One+SC' rel='stylesheet' type='text/css'>
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">

    <style>


        
        
        
        
        
        
        


.container {
            display: grid;
            grid-template-columns: 300px ;
            grid-gap: 25px;
            justify-content: center;
            align-items: center;
            height: 100vh;

            font-family: 'Baloo Paaji 2', cursive;
        }

        .card {
            background-color: #222831;
            height: 45rem;
            border-radius: 5px;
            display: flex;
            flex-direction: column;

            box-shadow: rgba(0, 0, 0, 0.7);
            color: white;
        }



        .draw-border {
            box-shadow: inset 0 0 0 4px #58cdd1;
            color: #58afd1;
            -webkit-transition: color 0.25s 0.0833333333s;
            transition: color 0.25s 0.0833333333s;
            position: relative;
        }

        .draw-border::before,
        .draw-border::after {
            border: 0 solid transparent;
            box-sizing: border-box;
            content: '';
            pointer-events: none;
            position: absolute;
            width: 0rem;
            height: 0;
            bottom: 0;
            right: 0;
        }

        .draw-border::before {
            border-bottom-width: 4px;
            border-left-width: 4px;
        }

        .draw-border::after {
            border-top-width: 4px;
            border-right-width: 4px;
        }

        .draw-border:hover {
            color: #ffe593;
        }

        .draw-border:hover::before,
        .draw-border:hover::after {
            border-color: #eb196e;
            -webkit-transition: border-color 0s, width 0.25s, height 0.25s;
            transition: border-color 0s, width 0.25s, height 0.25s;
            width: 100%;
            height: 100%;
        }

        .draw-border:hover::before {
            -webkit-transition-delay: 0s, 0s, 0.25s;
            transition-delay: 0s, 0s, 0.25s;
        }

        .draw-border:hover::after {
            -webkit-transition-delay: 0s, 0.25s, 0s;
            transition-delay: 0s, 0.25s, 0s;
        }

        .btn {
            background: none;
            border: none;
            cursor: pointer;
            line-height: 1.5;
            font: 700 1.2rem 'Roboto Slab', sans-serif;
            padding: 0.75em 2em;
            letter-spacing: 0.05rem;
            margin: 1em;
            width: 13rem;
        }

        .btn:focus {
            outline: 2px dotted #55d7dc;
        }


        .social-icons {
            padding: 0;
            list-style: none;
            margin: 1em;
        }

        .social-icons li {
            display: inline-block;
            margin: 0.15em;
            position: relative;
            font-size: 1em;
        }

        .social-icons i {
            color: #fff;
            position: absolute;
            top: 0.95em;
            left: 0.96em;
            transition: all 265ms ease-out;
        }

        .social-icons a {
            display: inline-block;
        }

        .social-icons a:before {
            transform: scale(1);
            -ms-transform: scale(1);
            -webkit-transform: scale(1);
            content: " ";
            width: 45px;
            height: 45px;
            border-radius: 100%;
            display: block;
            background: linear-gradient(45deg, #ff003c, #c648c8);
            transition: all 265ms ease-out;
        }

        .social-icons a:hover:before {
            transform: scale(0);
            transition: all 265ms ease-in;
        }

        .social-icons a:hover i {
            transform: scale(2.2);
            -ms-transform: scale(2.2);
            -webkit-transform: scale(2.2);
            color: #ff003c;
            background: -webkit-linear-gradient(45deg, #ff003c, #c648c8);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            transition: all 265ms ease-in;
        }

        .grid-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            grid-gap: 20px;
            font-size: 1.2em;
        }
        body {

            background: url("https://thumbs.dreamstime.com/b/people-eating-healthy-meals-wooden-table-top-view-food-delivery-people-eating-healthy-meals-wooden-table-food-delivery-160387494.jpg") no-repeat center;
            height: 100%;


            background-position: center;
            background-repeat: repeat;
            background-size: cover;
        }
        h4 {
            font-size: 23px;
            position: absolute;
            top: 50px;
            left:20px;
        }
    </style>
</head>
<?php echo $__env->make('CookNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

<div class="container">
    <?php if($mydata !=null): ?>

    <div class="card">
        <h1 style="text-align:center"> <span class="glyphicon glyphicon-cutlery"></span> <?php echo e($mydata->name); ?> <span class="glyphicon glyphicon-cutlery"></span></h1>
        <img src="<?php echo e($mydata->image); ?> " style="width: 100%"><br>





    </div>


    <?php endif; ?>



</div>
</body>
</html>
<?php /**PATH C:\xamppp\htdocs\Laravel_Project_2022\resources\views/CookMain.blade.php ENDPATH**/ ?>