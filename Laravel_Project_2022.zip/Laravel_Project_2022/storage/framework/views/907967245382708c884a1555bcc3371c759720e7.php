<p>User id: <?php echo e(Auth::user()->id); ?></p>

<p>Name akel : <?php echo e($data->name); ?></p>

<p>Menu id : <?php echo e($data->id); ?></p>


<?php /**PATH C:\xamppp\htdocs\Laravel_Project_2022\resources\views/addtocart.blade.php ENDPATH**/ ?>