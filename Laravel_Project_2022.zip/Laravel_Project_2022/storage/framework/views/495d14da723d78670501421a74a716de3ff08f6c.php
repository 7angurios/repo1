


<?php $__currentLoopData = $mydata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h2 class="module-title">User  Id = <?php echo e(Auth::user()->id); ?></h2>
    <h2 class="module-title">Cart  Id = <?php echo e($obj->cart_id); ?></h2>
    <h2 class="module-title">Menu id = <?php echo e($obj->menu_id); ?></h2>
    <h2 class="module-title">Quantity = <?php echo e($obj->quantity); ?></h2>
    <p>----------------------------</p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php /**PATH C:\xamppp\htdocs\Laravel_Project_2022\resources\views/listCart.blade.php ENDPATH**/ ?>