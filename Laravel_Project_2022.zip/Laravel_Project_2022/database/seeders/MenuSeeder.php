<?php

namespace Database\Seeders;

use App\Models\menu;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class MenuSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('menus')->insert([
            'name' => ' classic pizza ',
            'price' => 20,
            'description' => 'Xlarge',
            'category' => 'pizza',
            'cuisine' => 'lebanese',
            'restaurant_id' => 1,
            'image' => 'https://media-cdn.tripadvisor.com/media/photo-s/11/e6/c6/45/pizza-hut.jpg'
        ]);

        DB::table('menus')->insert([
            'name' => 'pizza four cheese',
            'price' => 45,
            'description' => 'Family',
            'category' => 'pizza',
            'cuisine' => 'lebanese',
            'restaurant_id' => 1,
            'image' => 'https://media-cdn.tripadvisor.com/media/photo-s/0e/54/ea/06/pizza-hut.jpg'
        ]);

        DB::table('menus')->insert([
            'name' => 'pizza peperoni',
            'price' => 25,
            'description' => 'Small',
            'category' => 'pizza',
            'cuisine' => 'lebanese',
            'restaurant_id' => 1,
            'image' => 'https://myfoodbook.com.au/sites/default/files/styles/sr_wd/public/recipe_photo/pepperoni-pizza.jpg'
        ]);

        DB::table('menus')->insert([
            'name' => 'Tawouk',
            'price' => 10,
            'description' => 'Marinated chicken breast, fries, coleslaw, garlic, pickles and ketchup',
            'category' => 'Sandwishes',
            'cuisine' => 'lebanese',
            'restaurant_id' => 2,
            'image' => 'https://app.malakaltawouk.com/storage/69/STGyGKrIcZ2mnutc.jpg'
        ]);
        DB::table('menus')->insert([
            'name' => 'Soujouk Platter',
            'price' => 15,
            'description' => 'Soujouk sausage, tomato, fries, pickles and mayo',
            'category' => 'Plat',
            'cuisine' => 'lebanese',
            'restaurant_id' => 2,
            'image' => 'https://app.malakaltawouk.com/storage/54/HhdO9h1UBUsX3Zbs.jpg'
        ]);
        DB::table('menus')->insert([
            'name' => 'Pepsi Bottle',
            'price' => 3,
            'description' => 'Sugar Free',
            'category' => 'Drinks',
            'cuisine' => 'lebanese',
            'restaurant_id' => 2,
            'image' => '	https://app.malakaltawouk.com/storage/67/xqDCFyaYShdZHJJZ.jpg'
        ]);

        DB::table('menus')->insert([
            'name' => 'Chicken Strips',
            'price' => 17,
            'description' => 'Our signature lightly breaded chicken strips that you know and love, served with our famous honey mustard dip.',
            'category' => 'Appetizer',
            'cuisine' => 'american',
            'restaurant_id' => 3,
            'image' => 'https://gethealthyu.com/wp-content/uploads/2012/12/shutterstock_199093157-500x500.jpg.webp'
        ]);
        DB::table('menus')->insert([
            'name' => 'Kale Shrimp Wasabi',
            'price' => 30,
            'description' => 'Fresh kale topped with juicy flame-grilled shrimp coated with wasabi, sesame seeds, organic quinoa, crunchy peanuts and dried cranberries. Tossed with sesame balsamic dressing.',
            'category' => 'Salad',
            'cuisine' => 'italian',
            'restaurant_id' => 3,
            'image' => 'https://images.squarespace-cdn.com/content/v1/5cf61220ea0e100001054f32/0110edce-09fc-43dc-a051-eb8b1c78c8dc/Grilled%2BShrimp%2Band%2BPeach%2BSalad.jpg?format=750w'
        ]);
        DB::table('menus')->insert([
            'name' => 'Vegan Burger',
            'price' => 3,
            'description' => 'Our exclusive vegan patty, served in a vegan bun and topped with grilled fresh onions and tomatoes, grilled fresh mushrooms, fresh rocket
                             leaves, crisp Lollo Verde lettuce and our special vegan sauce.',
            'category' => 'vegan',
            'cuisine' => 'italian',
            'restaurant_id' => 3,
            'image' => 'https://www.foodandwine.com/thmb/_hz1-1jxHmNJxNLZxIjlOs2QQ3E=/750x0/filters:no_upscale():max_bytes(150000):strip_icc():format(webp)/Ultimate-Veggie-Burgers-FT-Recipe-0821-5d7532c53a924a7298d2175cf1d4219f.jpg'
        ]);


        DB::table('menus')->insert([
            'name' => 'Potato',
            'price' => 5,
            'description' => 'Salty',
            'category' => 'Appetizer',
            'cuisine' => 'International',
            'restaurant_id' => 4,
            'image' => 'https://mcdonalds.com.lb/storage/menu-products/Fries-Large.png'
        ]);
        DB::table('menus')->insert([
            'name' => 'McFlurry',
            'price' => 5,
            'description' => 'KitKat,Sweet',
            'category' => 'Desert',
            'cuisine' => 'International',
            'restaurant_id' => 4,
            'image' => 'https://mcdonalds.com.lb/storage/menu-products/McFlurry-KitKat.png'
        ]);
        DB::table('menus')->insert([
            'name' => 'Water',
            'price' => 1,
            'description' => 'Cold',
            'category' => 'Drink',
            'cuisine' => 'Lebanese',
            'restaurant_id' => 4,
            'image' => 'https://mcdonalds.com.lb/storage/menu-products/January2021/ouYwOzijHGgE9HlEKaLC.png'
        ]);
    }
}
