<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class RestaurantsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('restaurants')->insert([
            'name' => 'PizzaHut',
            'image' => 'https://is1-ssl.mzstatic.com/image/thumb/Purple112/v4/ae/80/ec/ae80ecf0-6bcd-7aad-d1c2-f380a26be794/AppIcon-0-0-1x_U007emarketing-0-0-0-8-0-0-sRGB-0-0-0-GLES2_U002c0-512MB-85-220-0-0.png/246x0w.webp',
            'email' =>  'pizzahut@gmail.com',
            'number' => '01123456',
            'address' => 'Hadath',
            'cook_id' => 1,
            'status' => 0
        ]);
        DB::table('restaurants')->insert([
            'name' => 'Malak Al Tawouk',
            'image' => 'https://www.malakaltawouk.com/assets/images/MalakElTaouk.png',
            'email' =>  'Malaktawouk@gmail.com',
            'number' => '01684247',
            'address' => 'Baabda',
            'cook_id' => 2,
            'status' => 1
        ]);
        DB::table('restaurants')->insert([
            'name' => 'Roadster',
            'image' => 'https://thefranchisetalk.com/wp-content/uploads/2020/12/Untitled-design-37.png',
            'email' =>  'roadster@hotmail.com',
            'number' => '03428532',
            'address' => 'Yarzeh',
            'cook_id' => 3,
            'status' => 0
        ]);
        DB::table('restaurants')->insert([
            'name' => 'Mcdonalds',
            'image' => 'https://www.mcdonalds.com.lb/images/logo.svg',
            'email' =>  'mcdo@hotmail.com',
            'number' => '03123456',
            'address' => 'Hazmieh',
            'cook_id' => 3,
            'status' => 1
        ]);

    }
}
