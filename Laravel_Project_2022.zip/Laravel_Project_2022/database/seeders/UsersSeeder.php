<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class UsersSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('users')->insert([
            'fname' => 'Peter',
            'lname' => 'Akoury',
            'contact' =>  '76143132',
            'address' => 'jezzine',
            'email' => 'peter@gmail.com',
            'password' => bcrypt('123456789'),
            'Role_id' => 1
        ]);
        DB::table('users')->insert([
            'fname' => 'Patrick',
            'lname' => 'Al Helou',
            'contact' =>  '76148279',
            'address' => 'Ayn el Remaneh',
            'email' => 'atrick@gmail.com',
            'password' => bcrypt('123456789'),
            'Role_id' => 2
        ]);
        DB::table('users')->insert([
            'fname' => 'Charbel',
            'lname' => 'Louak',
            'contact' =>  '81793579',
            'address' => 'Boutchay',
            'email' => 'Admin@gmail.com',
            'password' => bcrypt('123456789'),
            'Role_id' => 3
        ]);
    }
}
